-- ══════════════════════════════════════════════
--  ELECAM — Script SQL de création de la base
--  Exécutez ce fichier dans phpMyAdmin ou MySQL
-- ══════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS elecam_cameroun
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE elecam_cameroun;

-- ── TABLE COMMUNES ──
CREATE TABLE IF NOT EXISTS communes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    region      VARCHAR(50)  NOT NULL,
    inscrits    INT          DEFAULT 0,
    bureaux     INT          DEFAULT 0,
    observations TEXT,
    statut      ENUM('actif','inactif') DEFAULT 'actif',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── TABLE PARTIS ──
CREATE TABLE IF NOT EXISTS partis (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    sigle   VARCHAR(20)  NOT NULL,
    nom     VARCHAR(200) NOT NULL,
    couleur VARCHAR(10)  DEFAULT '#888888'
) ENGINE=InnoDB;

-- ── TABLE CANDIDATS ──
CREATE TABLE IF NOT EXISTS candidats (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100),
    parti_id    INT,
    commune_id  INT,
    num_liste   VARCHAR(50),
    cni         VARCHAR(50)  UNIQUE,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (commune_id) REFERENCES communes(id) ON DELETE SET NULL,
    FOREIGN KEY (parti_id)   REFERENCES partis(id)   ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── TABLE VOTES ──
CREATE TABLE IF NOT EXISTS votes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    candidat_id INT NOT NULL,
    commune_id  INT NOT NULL,
    bureau      VARCHAR(50),
    voix        INT DEFAULT 0,
    nuls        INT DEFAULT 0,
    blancs      INT DEFAULT 0,
    saisi_le    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidat_id) REFERENCES candidats(id) ON DELETE CASCADE,
    FOREIGN KEY (commune_id)  REFERENCES communes(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ══ DONNÉES DE DÉMONSTRATION ══

-- Partis
INSERT INTO partis (sigle, nom, couleur) VALUES
('RDPC',  'Rassemblement Démocratique du Peuple Camerounais', '#007A5E'),
('SDF',   'Social Democratic Front',                          '#4A9EFF'),
('UNDP',  'Union Nationale pour la Démocratie et le Progrès','#FCD116'),
('UDC',   'Union Démocratique du Cameroun',                  '#CE1126'),
('MDR',   'Mouvement pour la Défense de la République',      '#A29BFE'),
('IND',   'Indépendant',                                      '#888888');

-- Communes
INSERT INTO communes (nom, region, inscrits, bureaux, statut) VALUES
('Yaoundé 1er',   'Centre',        120000, 45, 'actif'),
('Yaoundé 2e',    'Centre',         95000, 36, 'actif'),
('Douala 1er',    'Littoral',      180000, 62, 'actif'),
('Douala 2e',     'Littoral',      150000, 54, 'actif'),
('Bafoussam',     'Ouest',          55000, 20, 'actif'),
('Garoua',        'Nord',           48000, 18, 'actif'),
('Maroua',        'Extrême-Nord',   62000, 25, 'actif'),
('Bamenda',       'Nord-Ouest',     51000, 19, 'inactif'),
('Bertoua',       'Est',            32000, 14, 'actif'),
('Ebolowa',       'Sud',            28000, 11, 'actif'),
('Buea',          'Sud-Ouest',      38000, 16, 'actif'),
('Ngaoundéré',    'Adamaoua',       44000, 17, 'actif');
