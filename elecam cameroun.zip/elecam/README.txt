# ELECAM — Système de Gestion des Élections Municipales du Cameroun

## 📋 PRÉREQUIS

- **XAMPP** (recommandé) ou WAMP / MAMP
  - PHP 7.4 ou supérieur
  - MySQL 5.7 ou supérieur
  - Apache

---

## 🚀 INSTALLATION EN 5 ÉTAPES

### ÉTAPE 1 — Installer XAMPP

1. Téléchargez XAMPP sur : https://www.apachefriends.org/fr/index.html
2. Installez-le (par défaut dans `C:\xampp\`)
3. Lancez **XAMPP Control Panel**
4. Cliquez **Start** sur **Apache** et **MySQL**

---

### ÉTAPE 2 — Copier le projet

Copiez le dossier **`elecam`** dans :
```
C:\xampp\htdocs\elecam\
```
La structure doit être :
```
C:\xampp\htdocs\elecam\
├── index.php
├── config\
│   └── database.php
├── ajax\
│   ├── communes.php
│   ├── candidats.php
│   ├── votes.php
│   ├── export_xml.php
│   └── test_db.php
├── css\
│   └── style.css
├── js\
│   └── elecam.js
├── sql\
│   └── elecam.sql
└── xml\        (dossier vide — créé automatiquement)
```

---

### ÉTAPE 3 — Créer la base de données

**Option A — Via phpMyAdmin (recommandé) :**
1. Ouvrez votre navigateur et allez sur : http://localhost/phpmyadmin
2. Cliquez sur **"Importer"** (onglet en haut)
3. Cliquez sur **"Choisir un fichier"**
4. Sélectionnez le fichier `sql\elecam.sql` dans votre projet
5. Cliquez sur **"Exécuter"** en bas de la page
6. ✅ La base `elecam_cameroun` et toutes les tables sont créées

**Option B — Via la console MySQL :**
```bash
mysql -u root -p < C:\xampp\htdocs\elecam\sql\elecam.sql
```

---

### ÉTAPE 4 — Vérifier la configuration

Ouvrez `config\database.php` et vérifiez :
```php
define('DB_HOST', 'localhost');   // Ne pas changer
define('DB_NAME', 'elecam_cameroun');  // Ne pas changer
define('DB_USER', 'root');        // Utilisateur MySQL (root par défaut avec XAMPP)
define('DB_PASS', '');            // Mot de passe vide par défaut avec XAMPP
```

Si votre MySQL a un mot de passe, modifiez `DB_PASS`.

---

### ÉTAPE 5 — Lancer l'application

Ouvrez votre navigateur et accédez à :
```
http://localhost/elecam/
```

✅ **L'application est opérationnelle !**

---

## 🔧 RÉSOLUTION DES PROBLÈMES COURANTS

### ❌ "Connexion BDD impossible"
- Vérifiez que MySQL est bien démarré dans XAMPP
- Vérifiez les paramètres dans `config/database.php`
- Testez via l'onglet **Configuration** → "Tester la connexion"

### ❌ "Page blanche" ou erreur 500
- Activez l'affichage des erreurs PHP :
  Ouvrez `C:\xampp\php\php.ini`, cherchez `display_errors = Off` → remplacez par `On`
  Redémarrez Apache dans XAMPP

### ❌ "Classe PDO introuvable"
- Dans `php.ini`, vérifiez que ces lignes sont décommentées (sans `;`) :
  ```
  extension=pdo_mysql
  extension=mysqli
  ```

### ❌ Les requêtes AJAX ne fonctionnent pas
- Vérifiez que vous accédez via `http://localhost/elecam/` et NON via `file:///...`
- Les requêtes AJAX nécessitent un serveur web (Apache)

---

## 📁 DESCRIPTION DES FICHIERS

| Fichier | Rôle |
|---|---|
| `index.php` | Page principale — interface complète |
| `config/database.php` | Connexion PDO à MySQL |
| `ajax/communes.php` | CRUD communes (list/add/update/delete/stats) |
| `ajax/candidats.php` | CRUD candidats + liste des partis |
| `ajax/votes.php` | CRUD votes + résultats + statistiques |
| `ajax/export_xml.php` | Export XML (DOMDocument PHP) + import |
| `ajax/test_db.php` | Test de connexion à la BDD |
| `css/style.css` | Styles — thème couleurs Cameroun |
| `js/elecam.js` | Toute la logique AJAX (fetch API) |
| `sql/elecam.sql` | Script SQL complet (tables + données démo) |

---

## 🌐 TECHNOLOGIES UTILISÉES

- **PHP 8+** — Backend, traitement des requêtes
- **MySQL / PDO** — Stockage des données
- **AJAX (Fetch API)** — Communication asynchrone
- **XML / DOMDocument** — Export et import de données
- **HTML5 / CSS3** — Interface utilisateur
- **JavaScript ES6** — Logique frontend

---

## 📞 SUPPORT

En cas de problème, vérifiez :
1. XAMPP → Apache et MySQL sont démarrés (bouton vert)
2. Accès via `http://localhost/elecam/` (pas `file://`)
3. Base de données importée via phpMyAdmin
4. Fichier `config/database.php` correctement configuré
