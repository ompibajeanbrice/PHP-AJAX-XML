<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ELECAM — Gestion des Élections Municipales du Cameroun</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=IBM+Plex+Mono:wght@400;600&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- ══ AJAX FEEDBACK ══ -->
<div class="ajax-feedback" id="ajaxFeedback"></div>

<!-- ══ HEADER ══ -->
<header>
  <div class="header-stripe"></div>
  <div class="header-inner">
    <div class="logo-flag">
      <div class="flag-bar g"></div>
      <div class="flag-bar r"></div>
      <div class="flag-bar y"></div>
      <span class="star-logo">★</span>
    </div>
    <div class="brand">
      <h1>ELECAM</h1>
      <p>Système de Gestion des Élections Municipales — République du Cameroun</p>
    </div>
    <div class="header-right">
      <div class="status-badge">
        <div class="status-dot"></div>
        Système Actif
      </div>
      <div class="status-badge gold-badge">⚡ PHP + XML + AJAX</div>
    </div>
  </div>
</header>

<!-- ══ NAV ══ -->
<nav>
  <button class="nav-btn active" onclick="showTab('dashboard')" data-tab="dashboard"><span class="nav-icon">📊</span> Tableau de Bord</button>
  <button class="nav-btn" onclick="showTab('communes')"   data-tab="communes"><span class="nav-icon">🏛️</span> Communes</button>
  <button class="nav-btn" onclick="showTab('candidats')"  data-tab="candidats"><span class="nav-icon">👤</span> Candidats</button>
  <button class="nav-btn" onclick="showTab('votes')"      data-tab="votes"><span class="nav-icon">🗳️</span> Saisie des Votes</button>
  <button class="nav-btn" onclick="showTab('resultats')"  data-tab="resultats"><span class="nav-icon">📈</span> Résultats</button>
  <button class="nav-btn" onclick="showTab('xml')"        data-tab="xml"><span class="nav-icon">📄</span> Export XML</button>
  <button class="nav-btn" onclick="showTab('config')"     data-tab="config"><span class="nav-icon">⚙️</span> Configuration</button>
</nav>

<!-- ══ APP BODY ══ -->
<div class="app-body">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-section">
      <div class="sidebar-label">Régions du Cameroun</div>
      <div id="regionsList">
        <?php
        // Affichage PHP des régions depuis la BDD
        $regions = [
            'Adamaoua','Centre','Est','Extrême-Nord',
            'Littoral','Nord','Nord-Ouest','Ouest','Sud','Sud-Ouest'
        ];
        $colors = [
            'Adamaoua'=>'#FF6B7A','Centre'=>'#FCD116','Est'=>'#55EFC4',
            'Extrême-Nord'=>'#FF9F43','Littoral'=>'#007A5E','Nord'=>'#4A9EFF',
            'Nord-Ouest'=>'#A29BFE','Ouest'=>'#CE1126','Sud'=>'#FDA7DF','Sud-Ouest'=>'#74B9FF'
        ];
        foreach ($regions as $r):
        ?>
        <div class="region-item" onclick="filterByRegion('<?= htmlspecialchars($r) ?>')">
          <div class="region-dot" style="background:<?= $colors[$r] ?? '#888' ?>"></div>
          <div class="region-name"><?= htmlspecialchars($r) ?></div>
          <div class="region-count" id="cnt-<?= preg_replace('/\W/','_',$r) ?>">—</div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <hr class="divider">
    <div class="sidebar-section">
      <div class="sidebar-label">Scrutin en cours</div>
      <div class="scrutin-box">
        <div class="scrutin-row"><span class="scrutin-label">Type</span><span>Élections Municipales</span></div>
        <div class="scrutin-row"><span class="scrutin-label">Date</span><span><?= date('d/m/Y') ?></span></div>
        <div class="scrutin-row"><span class="scrutin-label">Tour</span><span class="badge badge-gold">1er Tour</span></div>
      </div>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main">

    <!-- ════ DASHBOARD ════ -->
    <div class="tab-panel active" id="tab-dashboard">
      <div class="page-title">Tableau de Bord</div>
      <div class="page-sub">// ÉLECTIONS MUNICIPALES — CAMEROUN 2025 — DONNÉES EN TEMPS RÉEL</div>

      <div class="stats-grid">
        <div class="stat-card green">
          <div class="stat-label">Communes enregistrées</div>
          <div class="stat-value" id="statCommunes"><span class="loader"></span></div>
          <div class="stat-sub">sur 360 communes au Cameroun</div>
        </div>
        <div class="stat-card red">
          <div class="stat-label">Candidats inscrits</div>
          <div class="stat-value" id="statCandidats"><span class="loader"></span></div>
          <div class="stat-sub">toutes listes confondues</div>
        </div>
        <div class="stat-card gold">
          <div class="stat-label">Votes enregistrés</div>
          <div class="stat-value" id="statVotes"><span class="loader"></span></div>
          <div class="stat-sub">bulletins valides comptés</div>
        </div>
        <div class="stat-card blue">
          <div class="stat-label">Taux de participation</div>
          <div class="stat-value" id="statParticipation"><span class="loader"></span></div>
          <div class="stat-sub">inscrits ayant voté</div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <span class="card-title">⚡ Journal d'activité AJAX</span>
          <button class="btn btn-outline" onclick="clearLog()" style="font-size:0.7rem;padding:6px 12px;">Effacer</button>
        </div>
        <div id="activityLog" style="padding:16px; max-height:200px; overflow-y:auto;">
          <div style="font-family:'IBM Plex Mono',monospace;font-size:0.75rem;color:var(--muted);">
            <span style="color:var(--green);">[INIT]</span> Système ELECAM démarré · PHP <?= PHP_VERSION ?> · Prêt...
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">🗺️ Résultats par Région</span></div>
        <div id="regionResults" style="padding:20px;">
          <div class="text-muted">Chargement...</div>
        </div>
      </div>
    </div>

    <!-- ════ COMMUNES ════ -->
    <div class="tab-panel" id="tab-communes">
      <div class="page-title">Gestion des Communes</div>
      <div class="page-sub">// AJOUT, MODIFICATION ET CONSULTATION — REQUÊTES AJAX → PHP → MySQL</div>

      <div class="card" style="margin-bottom:20px;">
        <div class="card-header"><span class="card-title">➕ Ajouter une Commune</span></div>
        <div style="padding:20px;">
          <div class="form-grid">
            <div class="form-group">
              <label>Nom de la Commune</label>
              <input type="text" id="commNom" placeholder="ex: Yaoundé 1er">
            </div>
            <div class="form-group">
              <label>Région</label>
              <select id="commRegion">
                <option value="">-- Sélectionner --</option>
                <?php foreach ($regions as $r): ?>
                <option><?= htmlspecialchars($r) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Nombre d'inscrits</label>
              <input type="number" id="commInscrits" placeholder="ex: 45000" min="0">
            </div>
            <div class="form-group">
              <label>Nombre de bureaux de vote</label>
              <input type="number" id="commBureaux" placeholder="ex: 24" min="0">
            </div>
            <div class="form-group full">
              <label>Observations</label>
              <textarea id="commObs" placeholder="Informations complémentaires..."></textarea>
            </div>
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" onclick="addCommune()">✓ Enregistrer la Commune</button>
            <button class="btn btn-outline" onclick="resetForm(['commNom','commRegion','commInscrits','commBureaux','commObs'])">✕ Réinitialiser</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <span class="card-title">📋 Liste des Communes</span>
          <div class="gap">
            <div class="search-input-wrap" style="width:220px;">
              <span class="search-icon">🔍</span>
              <input type="text" id="commSearch" placeholder="Rechercher..." oninput="loadCommunes(this.value)">
            </div>
            <button class="btn btn-success" onclick="loadCommunes()">↻ Actualiser</button>
          </div>
        </div>
        <table>
          <thead><tr><th>#</th><th>Commune</th><th>Région</th><th>Inscrits</th><th>Bureaux</th><th>Statut</th><th>Actions</th></tr></thead>
          <tbody id="communesBody"><tr><td colspan="7" style="text-align:center"><span class="loader"></span></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- ════ CANDIDATS ════ -->
    <div class="tab-panel" id="tab-candidats">
      <div class="page-title">Gestion des Candidats</div>
      <div class="page-sub">// INSCRIPTION DES LISTES ET CANDIDATS PAR COMMUNE</div>

      <div class="card" style="margin-bottom:20px;">
        <div class="card-header"><span class="card-title">➕ Inscrire un Candidat / une Liste</span></div>
        <div style="padding:20px;">
          <div class="form-grid">
            <div class="form-group"><label>Nom</label><input type="text" id="candNom" placeholder="NOM"></div>
            <div class="form-group"><label>Prénom</label><input type="text" id="candPrenom" placeholder="Prénom"></div>
            <div class="form-group"><label>Parti Politique</label><select id="candParti"><option value="">Chargement...</option></select></div>
            <div class="form-group"><label>Commune</label><select id="candCommune"><option value="">-- Sélectionner --</option></select></div>
            <div class="form-group"><label>Numéro de liste</label><input type="text" id="candListe" placeholder="ex: Liste N°3"></div>
            <div class="form-group"><label>N° CNI</label><input type="text" id="candCNI" placeholder="CMR123456789"></div>
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" onclick="addCandidat()">✓ Inscrire le Candidat</button>
            <button class="btn btn-outline" onclick="resetForm(['candNom','candPrenom','candParti','candCommune','candListe','candCNI'])">✕ Réinitialiser</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <span class="card-title">📋 Liste des Candidats</span>
          <div class="gap">
            <select id="filterCommune" style="width:200px;font-size:0.78rem;padding:6px 10px;" onchange="loadCandidats(this.value)">
              <option value="">Toutes communes</option>
            </select>
            <button class="btn btn-success" onclick="loadCandidats()">↻ Actualiser</button>
          </div>
        </div>
        <table>
          <thead><tr><th>#</th><th>Nom & Prénom</th><th>Parti</th><th>Liste</th><th>Commune</th><th>CNI</th><th>Actions</th></tr></thead>
          <tbody id="candidatsBody"><tr><td colspan="7" style="text-align:center"><span class="loader"></span></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- ════ VOTES ════ -->
    <div class="tab-panel" id="tab-votes">
      <div class="page-title">Saisie des Résultats de Vote</div>
      <div class="page-sub">// ENCODAGE DES BULLETINS PAR BUREAU DE VOTE — VALIDATION AJAX</div>

      <div class="card" style="margin-bottom:20px;">
        <div class="card-header"><span class="card-title">🗳️ Saisir les Votes</span></div>
        <div style="padding:20px;">
          <div class="form-grid">
            <div class="form-group"><label>Commune</label><select id="voteCommune" onchange="loadCandidatsForVote()"><option value="">-- Sélectionner --</option></select></div>
            <div class="form-group"><label>Bureau de Vote N°</label><input type="text" id="voteBureau" placeholder="ex: Bureau 05-A"></div>
            <div class="form-group"><label>Candidat</label><select id="voteCandidat"><option value="">-- Sélectionner une commune --</option></select></div>
            <div class="form-group"><label>Nombre de Voix</label><input type="number" id="voteVoix" placeholder="ex: 1234" min="0"></div>
            <div class="form-group"><label>Bulletins Nuls</label><input type="number" id="voteNuls" placeholder="ex: 12" min="0"></div>
            <div class="form-group"><label>Bulletins Blancs</label><input type="number" id="voteBlancs" placeholder="ex: 8" min="0"></div>
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" onclick="saisirVote()">✓ Valider le Scrutin</button>
            <button class="btn btn-outline" onclick="resetForm(['voteCommune','voteBureau','voteCandidat','voteVoix','voteNuls','voteBlancs'])">✕ Réinitialiser</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">📋 Votes saisis</span></div>
        <table>
          <thead><tr><th>#</th><th>Commune</th><th>Bureau</th><th>Candidat</th><th>Parti</th><th>Voix</th><th>Actions</th></tr></thead>
          <tbody id="votesBody"><tr><td colspan="7" style="text-align:center"><span class="loader"></span></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- ════ RÉSULTATS ════ -->
    <div class="tab-panel" id="tab-resultats">
      <div class="page-title">Résultats Électoraux</div>
      <div class="page-sub">// DÉPOUILLEMENT EN TEMPS RÉEL — MISE À JOUR AUTOMATIQUE</div>

      <div class="search-bar">
        <select id="resCommune" onchange="loadResultats()" style="width:260px;font-size:0.83rem;">
          <option value="">🗺️ Résultats nationaux</option>
        </select>
        <button class="btn btn-primary" onclick="loadResultats()">↻ Actualiser</button>
        <button class="btn btn-outline" onclick="toggleAutoRefresh()">⏱ Auto-refresh <span id="autoStatus">OFF</span></button>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">📊 Classement</span></div>
        <div class="chart-container" id="chartContainer"><div class="text-muted" style="padding:16px;">Chargement...</div></div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">📋 Tableau de dépouillement</span></div>
        <table>
          <thead><tr><th>Rang</th><th>Candidat</th><th>Parti</th><th>Commune</th><th>Voix</th><th>%</th><th>Statut</th></tr></thead>
          <tbody id="resultatsBody"><tr><td colspan="7" style="text-align:center"><span class="loader"></span></td></tr></tbody>
        </table>
      </div>
    </div>

    <!-- ════ XML ════ -->
    <div class="tab-panel" id="tab-xml">
      <div class="page-title">Export / Import XML</div>
      <div class="page-sub">// GÉNÉRATION PHP DE FICHIERS XML — ARCHIVAGE ET INTEROPÉRABILITÉ</div>

      <div class="card" style="margin-bottom:20px;">
        <div class="card-header"><span class="card-title">⚙️ Options d'export</span></div>
        <div style="padding:20px;display:flex;gap:12px;flex-wrap:wrap;">
          <button class="btn btn-primary"  onclick="previewXML('all')">👁 Aperçu complet</button>
          <button class="btn btn-outline"  onclick="previewXML('communes')">🏛️ Communes</button>
          <button class="btn btn-outline"  onclick="previewXML('candidats')">👤 Candidats</button>
          <button class="btn btn-outline"  onclick="previewXML('resultats')">📊 Résultats</button>
          <button class="btn btn-success"  onclick="downloadXML('all')">⬇ Télécharger XML</button>
        </div>
      </div>

      <div class="card" style="margin-bottom:20px;">
        <div class="card-header">
          <span class="card-title">🔍 Aperçu XML</span>
          <span id="xmlStats" style="font-family:'IBM Plex Mono',monospace;font-size:0.7rem;color:var(--muted);"></span>
        </div>
        <div id="xmlViewer" class="xml-viewer">
          <span class="xml-comment">&lt;!-- Cliquez sur un bouton ci-dessus pour générer l'aperçu XML --&gt;</span>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">📥 Importer un fichier XML</span></div>
        <div style="padding:20px;">
          <div class="form-group" style="margin-bottom:12px;">
            <label>Fichier XML à importer</label>
            <input type="file" id="xmlImport" accept=".xml">
          </div>
          <button class="btn btn-primary" onclick="importXML()">📥 Importer</button>
          <div id="importPreview" style="margin-top:12px;"></div>
        </div>
      </div>
    </div>

    <!-- ════ CONFIG ════ -->
    <div class="tab-panel" id="tab-config">
      <div class="page-title">Configuration Système</div>
      <div class="page-sub">// PARAMÈTRES DE CONNEXION PHP / MySQL</div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
        <div class="card">
          <div class="card-header"><span class="card-title">🔌 Connexion Base de Données</span></div>
          <div style="padding:20px;">
            <div class="form-group" style="margin-bottom:12px;"><label>Hôte MySQL</label><input type="text" id="dbHost" value="localhost"></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Base de Données</label><input type="text" id="dbName" value="elecam_cameroun"></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Utilisateur</label><input type="text" id="dbUser" value="root"></div>
            <div class="form-group" style="margin-bottom:16px;"><label>Mot de Passe</label><input type="password" id="dbPass" placeholder="••••••••"></div>
            <button class="btn btn-primary" onclick="testConnection()">⚡ Tester la connexion</button>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title">ℹ️ Informations serveur PHP</span></div>
          <div style="padding:20px;">
            <div class="form-group" style="margin-bottom:10px;"><label>Version PHP</label><input type="text" value="<?= PHP_VERSION ?>" readonly></div>
            <div class="form-group" style="margin-bottom:10px;"><label>Extensions actives</label>
              <input type="text" value="<?= implode(', ', array_filter(['PDO','pdo_mysql','simplexml','dom'], 'extension_loaded')) ?>" readonly>
            </div>
            <div class="form-group"><label>Date serveur</label><input type="text" value="<?= date('d/m/Y H:i:s') ?>" readonly></div>
          </div>
        </div>
      </div>
    </div>

  </main>
</div>

<script src="js/elecam.js"></script>
<script>
// ── INIT ──
function showTab(name) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    document.querySelector(`[data-tab="${name}"]`).classList.add('active');
    if (name === 'resultats') loadResultats();
}

function clearLog() {
    document.getElementById('activityLog').innerHTML =
        '<div style="font-family:\'IBM Plex Mono\',monospace;font-size:0.75rem;color:var(--muted);">Journal effacé.</div>';
}

function resetForm(ids) {
    ids.forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
}

function filterByRegion(r) {
    showTab('communes');
    setTimeout(() => {
        document.getElementById('commSearch').value = r;
        loadCommunes(r);
    }, 100);
}

// Lancement au chargement de la page
document.addEventListener('DOMContentLoaded', async () => {
    await loadStats();
    await loadCommunes();
    await populateCommuneSelects();
    await loadPartis();
    await loadCandidats();
    await loadVotes();
    await loadResultats();
    logActivity('INFO', 'Application ELECAM initialisée avec succès');
});
</script>
</body>
</html>
