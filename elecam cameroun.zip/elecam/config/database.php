<?php
// ══════════════════════════════════════════════
//  ELECAM — Configuration Base de Données
//  Modifiez ces paramètres selon votre config
// ══════════════════════════════════════════════

define('DB_HOST', 'localhost');
define('DB_NAME', 'elecam_cameroun');
define('DB_USER', 'root');
define('DB_PASS', '');          // Laissez vide si XAMPP sans mot de passe
define('DB_CHARSET', 'utf8mb4');

function getDB() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error'   => 'Connexion BDD impossible : ' . $e->getMessage()
        ]);
        exit;
    }
    return $pdo;
}
