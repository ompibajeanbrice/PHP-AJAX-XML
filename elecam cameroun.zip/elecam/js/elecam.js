// ══════════════════════════════════════════════
//  ELECAM — Logique AJAX JavaScript
//  js/elecam.js
// ══════════════════════════════════════════════

// ── REQUÊTE AJAX GÉNÉRIQUE ──
async function ajaxRequest(url, method = 'GET', data = null) {
    logActivity('AJAX', `${method} ${url}`);
    const options = { method };
    if (data) {
        const fd = new FormData();
        Object.entries(data).forEach(([k, v]) => fd.append(k, v));
        options.body = fd;
    }
    try {
        const res  = await fetch(url, options);
        const json = await res.json();
        if (json.success === false) throw new Error(json.error || 'Erreur serveur');
        logActivity('OK', json.message || 'Requête réussie');
        return json;
    } catch (err) {
        logActivity('ERR', err.message);
        showFeedback(err.message, 'error');
        throw err;
    }
}

// ── FEEDBACK VISUEL ──
function showFeedback(msg, type = 'success') {
    const el = document.getElementById('ajaxFeedback');
    el.textContent = type === 'success' ? '✓ ' + msg : type === 'error' ? '✕ ' + msg : '⚠ ' + msg;
    el.className = `ajax-feedback show${type !== 'success' ? ' ' + type : ''}`;
    setTimeout(() => el.classList.remove('show'), 3500);
}

// ── LOG D'ACTIVITÉ ──
function logActivity(type, msg) {
    const log = document.getElementById('activityLog');
    if (!log) return;
    const now = new Date().toLocaleTimeString('fr-FR');
    const colors = { INFO:'var(--gold)', AJAX:'#4A9EFF', OK:'var(--green)', ERR:'var(--red)' };
    const entry = document.createElement('div');
    entry.style.cssText = "font-family:'IBM Plex Mono',monospace;font-size:0.73rem;margin-bottom:4px;";
    entry.innerHTML = `<span style="color:${colors[type]||'#fff'};">[${type}]</span> <span style="color:var(--muted)">${now}</span> — ${msg}`;
    log.insertBefore(entry, log.firstChild);
}

// ── STATS DASHBOARD ──
async function loadStats() {
    try {
        const [votes, communes] = await Promise.all([
            fetch('ajax/votes.php?action=stats').then(r => r.json()),
            fetch('ajax/communes.php?action=stats').then(r => r.json())
        ]);
        document.getElementById('statCommunes').textContent = communes.data?.total || 0;
        document.getElementById('statVotes').textContent    = Number(votes.data?.total_voix || 0).toLocaleString('fr-FR');
        document.getElementById('statParticipation').textContent = (votes.data?.participation || 0) + '%';

        const cands = await fetch('ajax/candidats.php?action=list').then(r => r.json());
        document.getElementById('statCandidats').textContent = cands.data?.length || 0;
    } catch(e) { console.warn('Stats:', e.message); }
}

// ── COMMUNES ──
async function loadCommunes(q = '') {
    const res = await fetch(`ajax/communes.php?action=list&q=${encodeURIComponent(q)}`).then(r => r.json());
    renderCommunesTable(res.data || []);
    await populateCommuneSelects();
}

function renderCommunesTable(data) {
    const body = document.getElementById('communesBody');
    if (!data.length) {
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);">Aucun résultat</td></tr>';
        return;
    }
    const COLORS = {
        'Centre':'#FCD116','Littoral':'#007A5E','Ouest':'#CE1126','Nord':'#4A9EFF',
        'Extrême-Nord':'#FF9F43','Nord-Ouest':'#A29BFE','Est':'#55EFC4',
        'Sud':'#FDA7DF','Sud-Ouest':'#74B9FF','Adamaoua':'#FF6B7A'
    };
    body.innerHTML = data.map((c, i) => `
        <tr>
            <td style="font-family:'IBM Plex Mono',monospace;color:var(--muted);">${String(i+1).padStart(2,'0')}</td>
            <td><strong>${c.nom}</strong></td>
            <td><span style="display:inline-flex;align-items:center;gap:6px;">
                <span style="width:8px;height:8px;border-radius:50%;background:${COLORS[c.region]||'#888'};display:inline-block;"></span>
                ${c.region}</span></td>
            <td style="font-family:'IBM Plex Mono',monospace;">${Number(c.inscrits).toLocaleString('fr-FR')}</td>
            <td style="font-family:'IBM Plex Mono',monospace;">${c.bureaux}</td>
            <td><span class="badge ${c.statut==='actif'?'badge-green':'badge-red'}">${c.statut}</span></td>
            <td>
                <button class="btn btn-danger" style="padding:4px 10px;font-size:0.68rem;" onclick="deleteCommune(${c.id})">🗑</button>
            </td>
        </tr>
    `).join('');
}

async function addCommune() {
    const data = {
        action:       'add',
        nom:          document.getElementById('commNom').value.trim(),
        region:       document.getElementById('commRegion').value,
        inscrits:     document.getElementById('commInscrits').value,
        bureaux:      document.getElementById('commBureaux').value,
        observations: document.getElementById('commObs').value,
    };
    if (!data.nom || !data.region) { showFeedback('Nom et région requis', 'error'); return; }
    await ajaxRequest('ajax/communes.php', 'POST', data);
    showFeedback(`Commune "${data.nom}" enregistrée`);
    document.getElementById('commNom').value = '';
    document.getElementById('commInscrits').value = '';
    document.getElementById('commBureaux').value = '';
    document.getElementById('commObs').value = '';
    await loadCommunes();
    await loadStats();
}

async function deleteCommune(id) {
    if (!confirm('Supprimer cette commune ?')) return;
    await ajaxRequest('ajax/communes.php', 'POST', { action: 'delete', id });
    showFeedback('Commune supprimée');
    await loadCommunes();
    await loadStats();
}

async function populateCommuneSelects() {
    const res = await fetch('ajax/communes.php?action=list').then(r => r.json());
    ['candCommune','voteCommune','filterCommune','resCommune'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        const first = el.options[0];
        el.innerHTML = '';
        el.appendChild(first);
        (res.data || []).forEach(c => el.appendChild(new Option(c.nom, c.id)));
    });
}

// ── CANDIDATS ──
async function loadCandidats(communeId = '') {
    const url = communeId
        ? `ajax/candidats.php?action=list&commune_id=${communeId}`
        : 'ajax/candidats.php?action=list';
    const res = await fetch(url).then(r => r.json());
    renderCandidatsTable(res.data || []);
}

function renderCandidatsTable(data) {
    const body = document.getElementById('candidatsBody');
    if (!data.length) {
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);">Aucun candidat</td></tr>';
        return;
    }
    body.innerHTML = data.map((c, i) => `
        <tr>
            <td style="font-family:'IBM Plex Mono',monospace;color:var(--muted);">${String(i+1).padStart(2,'0')}</td>
            <td><strong>${c.nom}</strong> ${c.prenom || ''}</td>
            <td><span class="badge badge-blue">${c.parti_sigle || '—'}</span></td>
            <td style="font-family:'IBM Plex Mono',monospace;font-size:0.75rem;">${c.num_liste || '—'}</td>
            <td>${c.commune_nom || '—'}</td>
            <td style="font-family:'IBM Plex Mono',monospace;font-size:0.72rem;">${c.cni || '—'}</td>
            <td>
                <button class="btn btn-danger" style="padding:4px 10px;font-size:0.68rem;" onclick="deleteCandidat(${c.id})">🗑</button>
            </td>
        </tr>
    `).join('');
}

async function loadPartis() {
    const res = await fetch('ajax/candidats.php?action=partis').then(r => r.json());
    const sel = document.getElementById('candParti');
    if (!sel) return;
    sel.innerHTML = '<option value="">-- Sélectionner --</option>';
    (res.data || []).forEach(p => sel.appendChild(new Option(`${p.sigle} — ${p.nom}`, p.id)));
}

async function addCandidat() {
    const data = {
        action:     'add',
        nom:        document.getElementById('candNom').value.trim(),
        prenom:     document.getElementById('candPrenom').value.trim(),
        parti_id:   document.getElementById('candParti').value,
        commune_id: document.getElementById('candCommune').value,
        num_liste:  document.getElementById('candListe').value.trim(),
        cni:        document.getElementById('candCNI').value.trim(),
    };
    if (!data.nom) { showFeedback('Nom du candidat requis', 'error'); return; }
    const res = await ajaxRequest('ajax/candidats.php', 'POST', data);
    showFeedback(res.message);
    ['candNom','candPrenom','candParti','candCommune','candListe','candCNI']
        .forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
    await loadCandidats();
    await loadStats();
}

async function deleteCandidat(id) {
    if (!confirm('Supprimer ce candidat ?')) return;
    await ajaxRequest('ajax/candidats.php', 'POST', { action:'delete', id });
    showFeedback('Candidat supprimé');
    await loadCandidats();
}

async function loadCandidatsForVote() {
    const communeId = document.getElementById('voteCommune').value;
    const sel = document.getElementById('voteCandidat');
    if (!communeId) { sel.innerHTML = '<option>-- Sélectionner une commune --</option>'; return; }
    const res = await fetch(`ajax/candidats.php?action=list&commune_id=${communeId}`).then(r => r.json());
    sel.innerHTML = '<option value="">-- Sélectionner un candidat --</option>';
    (res.data || []).forEach(c => sel.appendChild(new Option(`${c.nom} ${c.prenom||''} (${c.parti_sigle||'—'})`, c.id)));
    if (!res.data?.length) sel.innerHTML = '<option>Aucun candidat pour cette commune</option>';
}

// ── VOTES ──
async function loadVotes() {
    const res = await fetch('ajax/votes.php?action=list').then(r => r.json());
    renderVotesTable(res.data || []);
}

function renderVotesTable(data) {
    const body = document.getElementById('votesBody');
    if (!data.length) {
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);">Aucun vote</td></tr>';
        return;
    }
    body.innerHTML = data.map((v, i) => `
        <tr>
            <td style="font-family:'IBM Plex Mono',monospace;color:var(--muted);">${String(i+1).padStart(2,'0')}</td>
            <td>${v.commune_nom || '—'}</td>
            <td style="font-family:'IBM Plex Mono',monospace;font-size:0.75rem;">${v.bureau}</td>
            <td><strong>${v.candidat_nom}</strong> ${v.candidat_prenom || ''}</td>
            <td><span class="badge badge-blue">${v.parti_sigle || '—'}</span></td>
            <td><strong style="color:var(--gold);font-family:'IBM Plex Mono',monospace;">${Number(v.voix).toLocaleString('fr-FR')}</strong></td>
            <td>
                <button class="btn btn-danger" style="padding:4px 10px;font-size:0.68rem;" onclick="deleteVote(${v.id})">🗑</button>
            </td>
        </tr>
    `).join('');
}

async function saisirVote() {
    const data = {
        action:      'add',
        commune_id:  document.getElementById('voteCommune').value,
        bureau:      document.getElementById('voteBureau').value.trim(),
        candidat_id: document.getElementById('voteCandidat').value,
        voix:        document.getElementById('voteVoix').value,
        nuls:        document.getElementById('voteNuls').value || 0,
        blancs:      document.getElementById('voteBlancs').value || 0,
    };
    if (!data.commune_id || !data.candidat_id || !data.bureau) {
        showFeedback('Commune, candidat et bureau requis', 'error'); return;
    }
    const res = await ajaxRequest('ajax/votes.php', 'POST', data);
    showFeedback(res.message);
    ['voteCommune','voteBureau','voteCandidat','voteVoix','voteNuls','voteBlancs']
        .forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
    await loadVotes();
    await loadStats();
}

async function deleteVote(id) {
    if (!confirm('Supprimer ce vote ?')) return;
    await ajaxRequest('ajax/votes.php', 'POST', { action:'delete', id });
    showFeedback('Vote supprimé');
    await loadVotes();
    await loadStats();
}

// ── RÉSULTATS ──
async function loadResultats() {
    const communeId = document.getElementById('resCommune')?.value || '';
    const url = `ajax/votes.php?action=resultats${communeId ? '&commune_id='+communeId : ''}`;
    const res = await fetch(url).then(r => r.json());
    renderResultatsChart(res.data || [], res.total || 0);
    renderResultatsTable(res.data || [], res.total || 0);
}

function renderResultatsChart(data, total) {
    const cont = document.getElementById('chartContainer');
    if (!data.length) { cont.innerHTML = '<div class="text-muted">Aucun vote disponible.</div>'; return; }
    const colors = ['#FCD116','#2ED573','#4A9EFF','#FF6B7A','#A29BFE','#FF9F43'];
    cont.innerHTML = data.map((item, i) => `
        <div class="result-row">
            <div class="result-header">
                <div>
                    <span class="candidate-name">${i===0?'👑 ':''} ${item.nom} ${item.prenom||''}</span>
                    <span class="party-tag">• ${item.parti||'—'}</span>
                </div>
                <div style="display:flex;gap:16px;">
                    <span class="vote-count">${Number(item.total_voix).toLocaleString('fr-FR')} voix</span>
                    <span class="vote-pct">${item.pourcentage}%</span>
                </div>
            </div>
            <div class="progress-wrap">
                <div class="progress-bar" style="width:${item.pourcentage}%;background:${colors[i%colors.length]};"></div>
            </div>
        </div>
    `).join('');
}

function renderResultatsTable(data, total) {
    const body = document.getElementById('resultatsBody');
    if (!data.length) {
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);">Aucune donnée</td></tr>';
        return;
    }
    body.innerHTML = data.map((item, i) => {
        const rang = i + 1;
        const badge = rang===1 ? '<span class="badge badge-gold">🥇 1er</span>'
                    : rang===2 ? '<span class="badge badge-blue">🥈 2e</span>'
                    : rang===3 ? '<span class="badge" style="background:rgba(139,90,43,.2);color:#CD7F32;border:1px solid rgba(139,90,43,.4)">🥉 3e</span>'
                    : `<span class="badge badge-blue">${rang}e</span>`;
        return `<tr>
            <td>${badge}</td>
            <td><strong>${item.nom}</strong> ${item.prenom||''}</td>
            <td><span class="badge badge-blue">${item.parti||'—'}</span></td>
            <td>${item.commune_nom||'—'}</td>
            <td style="font-family:'IBM Plex Mono',monospace;"><strong style="color:var(--gold);">${Number(item.total_voix).toLocaleString('fr-FR')}</strong></td>
            <td style="font-family:'IBM Plex Mono',monospace;">${item.pourcentage}%</td>
            <td>${rang===1 ? '<span class="badge badge-green">✓ Élu</span>' : '<span class="badge badge-red">Non élu</span>'}</td>
        </tr>`;
    }).join('');
}

let autoRefreshTimer = null;
function toggleAutoRefresh() {
    if (autoRefreshTimer) {
        clearInterval(autoRefreshTimer);
        autoRefreshTimer = null;
        document.getElementById('autoStatus').textContent = 'OFF';
        showFeedback('Auto-refresh désactivé', 'warn');
    } else {
        autoRefreshTimer = setInterval(loadResultats, 5000);
        document.getElementById('autoStatus').textContent = 'ON';
        showFeedback('Auto-refresh activé (5s)');
    }
}

// ── XML ──
function downloadXML(type) {
    window.open(`ajax/export_xml.php?action=export&type=${type}&download=1`, '_blank');
    logActivity('OK', `Export XML "${type}" déclenché`);
    showFeedback(`Export XML (${type}) lancé`);
}

function previewXML(type) {
    fetch(`ajax/export_xml.php?action=export&type=${type}`)
        .then(r => r.text())
        .then(xml => {
            const viewer = document.getElementById('xmlViewer');
            const lines = xml.split('\n').length;
            const size  = (new Blob([xml]).size / 1024).toFixed(1);
            document.getElementById('xmlStats').textContent = `${lines} lignes · ${size} KB`;
            const esc = xml.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                .replace(/&lt;!--[\s\S]*?--&gt;/g, m=>`<span class="xml-comment">${m}</span>`)
                .replace(/&lt;\/?([a-zA-Z_][a-zA-Z0-9_-]*)/g, (_,t)=>`&lt;<span class="xml-tag">${t}</span>`)
                .replace(/([a-zA-Z_-]+)="([^"]*)"/g, `<span class="xml-attr">$1</span>="<span class="xml-val">$2</span>"`);
            viewer.innerHTML = esc;
            showFeedback(`XML (${type}) généré · ${size} KB`);
        }).catch(e => showFeedback(e.message, 'error'));
}

function importXML() {
    const file = document.getElementById('xmlImport').files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('action', 'import');
    fd.append('xmlfile', file);
    fetch('ajax/export_xml.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(res => {
            showFeedback(res.message || 'Import effectué');
            document.getElementById('importPreview').innerHTML =
                `<span class="badge badge-green">✓ ${res.message}</span>`;
            loadCommunes();
        }).catch(e => showFeedback(e.message, 'error'));
}

// ── TEST CONNEXION ──
async function testConnection() {
    const host = document.getElementById('dbHost').value;
    const db   = document.getElementById('dbName').value;
    const user = document.getElementById('dbUser').value;
    const pass = document.getElementById('dbPass').value;
    logActivity('AJAX', `POST /ajax/test_db.php — host:${host}, db:${db}`);
    const res = await fetch(`ajax/test_db.php?host=${host}&db=${db}&user=${user}&pass=${encodeURIComponent(pass)}`).then(r => r.json());
    if (res.success) showFeedback('Connexion BDD réussie ✓');
    else showFeedback(res.error, 'error');
}
