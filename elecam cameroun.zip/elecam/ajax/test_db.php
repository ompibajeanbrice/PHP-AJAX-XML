<?php
// ══════════════════════════════════════════════
//  ELECAM — Test de connexion BDD
//  URL : ajax/test_db.php
// ══════════════════════════════════════════════
header('Content-Type: application/json; charset=utf-8');

$host = $_GET['host'] ?? 'localhost';
$db   = $_GET['db']   ?? 'elecam_cameroun';
$user = $_GET['user'] ?? 'root';
$pass = $_GET['pass'] ?? '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user, $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode([
        'success' => true,
        'message' => "Connexion réussie à $db@$host",
        'tables'  => $tables
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error'   => $e->getMessage()
    ]);
}
