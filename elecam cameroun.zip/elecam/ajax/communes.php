<?php
// ══════════════════════════════════════════════
//  ELECAM — AJAX : Gestion des Communes
//  URL : ajax/communes.php
// ══════════════════════════════════════════════
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$pdo    = getDB();
$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {

        // ── LISTER ──
        case 'list':
            $region = $_GET['region'] ?? '';
            $search = '%' . ($_GET['q'] ?? '') . '%';
            if ($region) {
                $stmt = $pdo->prepare("SELECT * FROM communes WHERE region = ? AND nom LIKE ? ORDER BY region, nom");
                $stmt->execute([$region, $search]);
            } else {
                $stmt = $pdo->prepare("SELECT * FROM communes WHERE nom LIKE ? OR region LIKE ? ORDER BY region, nom");
                $stmt->execute([$search, $search]);
            }
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        // ── AJOUTER ──
        case 'add':
            $nom      = trim($_POST['nom'] ?? '');
            $region   = trim($_POST['region'] ?? '');
            $inscrits = (int)($_POST['inscrits'] ?? 0);
            $bureaux  = (int)($_POST['bureaux'] ?? 0);
            $obs      = trim($_POST['observations'] ?? '');
            $statut   = $_POST['statut'] ?? 'actif';

            if (!$nom || !$region) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Nom et région requis']);
                exit;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO communes (nom, region, inscrits, bureaux, observations, statut)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$nom, $region, $inscrits, $bureaux, $obs, $statut]);
            $id = $pdo->lastInsertId();

            echo json_encode([
                'success' => true,
                'message' => "Commune \"$nom\" enregistrée",
                'id'      => $id
            ]);
            break;

        // ── MODIFIER ──
        case 'update':
            $id       = (int)$_POST['id'];
            $nom      = trim($_POST['nom'] ?? '');
            $region   = trim($_POST['region'] ?? '');
            $inscrits = (int)($_POST['inscrits'] ?? 0);
            $bureaux  = (int)($_POST['bureaux'] ?? 0);
            $statut   = $_POST['statut'] ?? 'actif';

            $stmt = $pdo->prepare(
                "UPDATE communes SET nom=?, region=?, inscrits=?, bureaux=?, statut=? WHERE id=?"
            );
            $stmt->execute([$nom, $region, $inscrits, $bureaux, $statut, $id]);

            echo json_encode(['success' => true, 'message' => 'Commune mise à jour']);
            break;

        // ── SUPPRIMER ──
        case 'delete':
            $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM communes WHERE id=?");
            $stmt->execute([$id]);
            echo json_encode(['success' => true, 'message' => 'Commune supprimée']);
            break;

        // ── STATS ──
        case 'stats':
            $row = $pdo->query("SELECT COUNT(*) AS total, SUM(inscrits) AS inscrits, SUM(bureaux) AS bureaux FROM communes WHERE statut='actif'")->fetch();
            echo json_encode(['success' => true, 'data' => $row]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => "Action inconnue: $action"]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
