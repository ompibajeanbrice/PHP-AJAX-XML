<?php
// ══════════════════════════════════════════════
//  ELECAM — AJAX : Gestion des Votes
//  URL : ajax/votes.php
// ══════════════════════════════════════════════
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$pdo    = getDB();
$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {

        // ── LISTER ──
        case 'list':
            $communeId = (int)($_GET['commune_id'] ?? 0);
            $sql = "SELECT v.*, c.nom AS candidat_nom, c.prenom AS candidat_prenom,
                           p.sigle AS parti_sigle, co.nom AS commune_nom, co.region
                    FROM votes v
                    JOIN candidats c  ON v.candidat_id = c.id
                    LEFT JOIN partis p ON c.parti_id   = p.id
                    JOIN communes co  ON v.commune_id  = co.id";
            if ($communeId) {
                $stmt = $pdo->prepare($sql . " WHERE v.commune_id = ? ORDER BY v.voix DESC");
                $stmt->execute([$communeId]);
            } else {
                $stmt = $pdo->query($sql . " ORDER BY v.voix DESC");
            }
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        // ── AJOUTER ──
        case 'add':
            $candidatId = (int)($_POST['candidat_id'] ?? 0);
            $communeId  = (int)($_POST['commune_id']  ?? 0);
            $bureau     = trim($_POST['bureau'] ?? '');
            $voix       = (int)($_POST['voix']   ?? 0);
            $nuls       = (int)($_POST['nuls']   ?? 0);
            $blancs     = (int)($_POST['blancs'] ?? 0);

            if (!$candidatId || !$communeId || !$bureau) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Candidat, commune et bureau requis']);
                exit;
            }
            if ($voix < 0 || $nuls < 0 || $blancs < 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Les valeurs ne peuvent pas être négatives']);
                exit;
            }

            // Vérifier doublon bureau + candidat
            $check = $pdo->prepare("SELECT id FROM votes WHERE candidat_id=? AND commune_id=? AND bureau=?");
            $check->execute([$candidatId, $communeId, $bureau]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Vote déjà enregistré pour ce candidat dans ce bureau']);
                exit;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO votes (candidat_id, commune_id, bureau, voix, nuls, blancs)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$candidatId, $communeId, $bureau, $voix, $nuls, $blancs]);
            $id = $pdo->lastInsertId();

            echo json_encode([
                'success' => true,
                'message' => "$voix voix enregistrées",
                'id'      => $id
            ]);
            break;

        // ── SUPPRIMER ──
        case 'delete':
            $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM votes WHERE id=?");
            $stmt->execute([$id]);
            echo json_encode(['success' => true, 'message' => 'Vote supprimé']);
            break;

        // ── RÉSULTATS PAR CANDIDAT ──
        case 'resultats':
            $communeId = (int)($_GET['commune_id'] ?? 0);
            $sql = "SELECT c.id, c.nom, c.prenom, p.sigle AS parti, p.couleur,
                           co.nom AS commune_nom, co.region,
                           SUM(v.voix) AS total_voix,
                           SUM(v.nuls) AS total_nuls,
                           SUM(v.blancs) AS total_blancs
                    FROM candidats c
                    JOIN votes v     ON v.candidat_id = c.id
                    LEFT JOIN partis p  ON c.parti_id  = p.id
                    LEFT JOIN communes co ON c.commune_id = co.id";
            if ($communeId) {
                $stmt = $pdo->prepare($sql . " WHERE v.commune_id=? GROUP BY c.id ORDER BY total_voix DESC");
                $stmt->execute([$communeId]);
            } else {
                $stmt = $pdo->query($sql . " GROUP BY c.id ORDER BY total_voix DESC");
            }
            $rows  = $stmt->fetchAll();
            $grand = array_sum(array_column($rows, 'total_voix'));
            foreach ($rows as &$r) {
                $r['pourcentage'] = $grand > 0 ? round(($r['total_voix'] / $grand) * 100, 2) : 0;
            }
            echo json_encode(['success' => true, 'data' => $rows, 'total' => $grand]);
            break;

        // ── STATS GLOBALES ──
        case 'stats':
            $stats = $pdo->query(
                "SELECT COUNT(*) AS nb_votes,
                        COALESCE(SUM(voix),0)   AS total_voix,
                        COALESCE(SUM(nuls),0)   AS total_nuls,
                        COALESCE(SUM(blancs),0) AS total_blancs
                 FROM votes"
            )->fetch();
            $inscrits = $pdo->query("SELECT COALESCE(SUM(inscrits),0) AS total FROM communes WHERE statut='actif'")->fetch()['total'];
            $stats['inscrits']      = $inscrits;
            $stats['participation'] = $inscrits > 0
                ? round(($stats['total_voix'] / $inscrits) * 100, 2) : 0;
            echo json_encode(['success' => true, 'data' => $stats]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => "Action inconnue: $action"]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
