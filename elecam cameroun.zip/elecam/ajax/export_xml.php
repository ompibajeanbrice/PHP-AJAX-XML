<?php
// ══════════════════════════════════════════════
//  ELECAM — AJAX : Export / Import XML
//  URL : ajax/export_xml.php
// ══════════════════════════════════════════════
require_once '../config/database.php';

$pdo    = getDB();
$action = $_REQUEST['action'] ?? 'export';
$type   = $_REQUEST['type']   ?? 'all';

// ── IMPORT XML ──
if ($action === 'import') {
    header('Content-Type: application/json; charset=utf-8');
    if (empty($_FILES['xmlfile'])) {
        echo json_encode(['success' => false, 'error' => 'Aucun fichier reçu']);
        exit;
    }
    $content = file_get_contents($_FILES['xmlfile']['tmp_name']);
    libxml_use_internal_errors(true);
    $xml = simplexml_load_string($content);
    if (!$xml) {
        $errors = array_map(fn($e) => $e->message, libxml_get_errors());
        echo json_encode(['success' => false, 'error' => 'XML invalide: ' . implode(', ', $errors)]);
        exit;
    }
    // Importer communes depuis XML
    $imported = 0;
    foreach ($xml->communes->commune ?? [] as $c) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO communes (nom, region, inscrits, bureaux) VALUES (?,?,?,?)");
        $stmt->execute([(string)$c->nom, (string)$c->region, (int)$c->inscrits, (int)$c->bureaux_de_vote]);
        $imported++;
    }
    echo json_encode(['success' => true, 'imported' => $imported, 'message' => "$imported communes importées"]);
    exit;
}

// ── EXPORT XML ──
header('Content-Type: application/xml; charset=utf-8');
if ($_REQUEST['download'] ?? false) {
    $filename = 'elecam_export_' . date('Y-m-d_H-i-s') . '.xml';
    header("Content-Disposition: attachment; filename=\"$filename\"");
}

$now = date('c');
$xml = new DOMDocument('1.0', 'UTF-8');
$xml->formatOutput = true;

// Commentaire
$xml->appendChild($xml->createComment(
    " Généré par ELECAM — Système de Gestion des Élections Municipales du Cameroun "
));
$xml->appendChild($xml->createComment(" Date: $now "));

// Racine
$root = $xml->createElement('elecam');
$root->setAttribute('version', '2.0');
$root->setAttribute('pays', 'Cameroun');
$root->setAttribute('date', $now);
$xml->appendChild($root);

// Scrutin
$scrutin = $xml->createElement('scrutin');
$scrutin->setAttribute('type', 'municipal');
$scrutin->setAttribute('tour', '1');
$scrutin->setAttribute('annee', '2025');
$root->appendChild($scrutin);

// ── COMMUNES ──
if ($type === 'all' || $type === 'communes') {
    $communes = $pdo->query("SELECT * FROM communes ORDER BY region, nom")->fetchAll();
    $communesEl = $xml->createElement('communes');
    $communesEl->setAttribute('total', count($communes));
    foreach ($communes as $c) {
        $el = $xml->createElement('commune');
        $el->setAttribute('id', $c['id']);
        $el->setAttribute('statut', $c['statut']);
        foreach (['nom','region','inscrits','bureaux','observations'] as $field) {
            $child = $xml->createElement($field === 'bureaux' ? 'bureaux_de_vote' : $field);
            $child->appendChild($xml->createTextNode($c[$field] ?? ''));
            $el->appendChild($child);
        }
        $communesEl->appendChild($el);
    }
    $root->appendChild($communesEl);
}

// ── CANDIDATS ──
if ($type === 'all' || $type === 'candidats') {
    $candidats = $pdo->query(
        "SELECT c.*, p.sigle AS parti_sigle, p.nom AS parti_nom, co.nom AS commune_nom
         FROM candidats c
         LEFT JOIN partis p ON c.parti_id=p.id
         LEFT JOIN communes co ON c.commune_id=co.id
         ORDER BY co.nom, c.nom"
    )->fetchAll();
    $candidatsEl = $xml->createElement('candidats');
    $candidatsEl->setAttribute('total', count($candidats));
    foreach ($candidats as $c) {
        $el = $xml->createElement('candidat');
        $el->setAttribute('id', $c['id']);
        $addChild = function($tag, $val) use ($xml, $el) {
            $child = $xml->createElement($tag);
            $child->appendChild($xml->createTextNode((string)($val ?? '')));
            $el->appendChild($child);
        };
        $addChild('nom', $c['nom']);
        $addChild('prenom', $c['prenom']);
        $addChild('parti_sigle', $c['parti_sigle']);
        $addChild('parti_nom', $c['parti_nom']);
        $addChild('num_liste', $c['num_liste']);
        $addChild('cni', $c['cni']);
        $commune = $xml->createElement('commune');
        $commune->setAttribute('ref', $c['commune_id']);
        $commune->appendChild($xml->createTextNode($c['commune_nom'] ?? ''));
        $el->appendChild($commune);
        $candidatsEl->appendChild($el);
    }
    $root->appendChild($candidatsEl);
}

// ── RÉSULTATS / VOTES ──
if ($type === 'all' || $type === 'resultats') {
    $votes = $pdo->query(
        "SELECT v.*, c.nom AS cand_nom, c.prenom AS cand_prenom,
                p.sigle AS parti, co.nom AS commune_nom
         FROM votes v
         JOIN candidats c ON v.candidat_id=c.id
         LEFT JOIN partis p ON c.parti_id=p.id
         JOIN communes co ON v.commune_id=co.id
         ORDER BY v.voix DESC"
    )->fetchAll();
    $totalVoix = array_sum(array_column($votes, 'voix'));
    $votesEl = $xml->createElement('resultats');
    $votesEl->setAttribute('total_voix', $totalVoix);
    foreach ($votes as $v) {
        $el = $xml->createElement('vote');
        $el->setAttribute('id', $v['id']);
        foreach (['commune_nom','bureau','voix','nuls','blancs'] as $f) {
            $child = $xml->createElement($f === 'commune_nom' ? 'commune' : $f);
            if ($f === 'commune_nom') $child->setAttribute('ref', $v['commune_id']);
            $child->appendChild($xml->createTextNode((string)($v[$f] ?? '')));
            $el->appendChild($child);
        }
        $cand = $xml->createElement('candidat');
        $cand->setAttribute('ref', $v['candidat_id']);
        $cand->appendChild($xml->createTextNode($v['cand_nom'] . ' ' . $v['cand_prenom']));
        $el->appendChild($cand);
        $votesEl->appendChild($el);
    }
    $root->appendChild($votesEl);
}

echo $xml->saveXML();
