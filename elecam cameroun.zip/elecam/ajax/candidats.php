<?php
// ══════════════════════════════════════════════
//  ELECAM — AJAX : Gestion des Candidats
//  URL : ajax/candidats.php
// ══════════════════════════════════════════════
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

$pdo    = getDB();
$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {

        // ── LISTER ──
        case 'list':
            $communeId = (int)($_GET['commune_id'] ?? 0);
            if ($communeId) {
                $stmt = $pdo->prepare(
                    "SELECT c.*, p.sigle AS parti_sigle, p.nom AS parti_nom, p.couleur,
                            co.nom AS commune_nom
                     FROM candidats c
                     LEFT JOIN partis p    ON c.parti_id   = p.id
                     LEFT JOIN communes co ON c.commune_id = co.id
                     WHERE c.commune_id = ?
                     ORDER BY c.nom"
                );
                $stmt->execute([$communeId]);
            } else {
                $stmt = $pdo->query(
                    "SELECT c.*, p.sigle AS parti_sigle, p.nom AS parti_nom, p.couleur,
                            co.nom AS commune_nom
                     FROM candidats c
                     LEFT JOIN partis p    ON c.parti_id   = p.id
                     LEFT JOIN communes co ON c.commune_id = co.id
                     ORDER BY co.nom, c.nom"
                );
            }
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        // ── AJOUTER ──
        case 'add':
            $nom       = trim($_POST['nom'] ?? '');
            $prenom    = trim($_POST['prenom'] ?? '');
            $partiId   = (int)($_POST['parti_id'] ?? 0) ?: null;
            $communeId = (int)($_POST['commune_id'] ?? 0) ?: null;
            $liste     = trim($_POST['num_liste'] ?? '');
            $cni       = trim($_POST['cni'] ?? '') ?: null;

            if (!$nom) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Nom du candidat requis']);
                exit;
            }

            // Vérifier CNI unique
            if ($cni) {
                $check = $pdo->prepare("SELECT id FROM candidats WHERE cni = ?");
                $check->execute([$cni]);
                if ($check->fetch()) {
                    echo json_encode(['success' => false, 'error' => 'Ce CNI est déjà enregistré']);
                    exit;
                }
            }

            $stmt = $pdo->prepare(
                "INSERT INTO candidats (nom, prenom, parti_id, commune_id, num_liste, cni)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$nom, $prenom, $partiId, $communeId, $liste, $cni]);
            $id = $pdo->lastInsertId();

            echo json_encode([
                'success' => true,
                'message' => "Candidat \"$nom $prenom\" inscrit",
                'id'      => $id
            ]);
            break;

        // ── SUPPRIMER ──
        case 'delete':
            $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM candidats WHERE id=?");
            $stmt->execute([$id]);
            echo json_encode(['success' => true, 'message' => 'Candidat supprimé']);
            break;

        // ── PARTIS ──
        case 'partis':
            $partis = $pdo->query("SELECT * FROM partis ORDER BY sigle")->fetchAll();
            echo json_encode(['success' => true, 'data' => $partis]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => "Action inconnue: $action"]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
